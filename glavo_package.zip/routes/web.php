<?php

use Illuminate\Support\Facades\Route;
use App\Http\Livewire\TeacherDashboard;
use App\Http\Livewire\FlashcardSwipe;

Route::view('/', 'welcome')->name('home');

Route::middleware(['auth', 'verified'])->group(function () {
    Route::view('dashboard', 'dashboard')->name('dashboard');
    
    // Teacher dashboard (requires auth & teacher role in real app)
    Route::get('/teacher', TeacherDashboard::class)->name('teacher.dashboard');
    Route::get('/learn', FlashcardSwipe::class)->name('learn.flashcards');
});

require __DIR__.'/settings.php';
