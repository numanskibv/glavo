<div class="min-h-screen flex flex-col items-center justify-between p-6 bg-gradient-to-b from-gray-900 to-black text-white">
    <div class="w-full max-w-md">
        <div class="mb-4 text-center text-sm text-gray-300">Groeten</div>

        <div id="card" class="relative bg-gray-800 rounded-3xl shadow-2xl p-8 text-center" style="min-height:400px;">
            @if($current)
                <div class="absolute inset-0 flex items-center justify-center">
                    <div class="w-full">
                        <div class="text-4xl font-bold" x-data>
                            <div wire:click="flip" class="cursor-pointer select-none">{{ $current->term->word }}</div>
                            @if($flipped)
                                <div class="mt-4 text-base text-gray-300">{{ $current->term->definition }}</div>
                            @endif
                        </div>
                    </div>
                </div>
            @else
                <div class="text-center text-gray-400 py-20">Geen kaarten meer</div>
            @endif
        </div>

        <div class="mt-6 flex items-center justify-between">
            <button onclick="emitSwipe('left')" class="px-4 py-3 bg-red-600 rounded-lg">Fout</button>
            <div class="text-center text-sm text-gray-300">Efficiëntie: {{ $this->efficiency }}% — Kaarten: {{ count($this->drawPile) + ($this->current ? 1 : 0) }}</div>
            <button onclick="emitSwipe('right')" class="px-4 py-3 bg-green-500 rounded-lg">Goed</button>
        </div>
    </div>

    <script>
        function emitSwipe(dir){
            if (!window.Livewire) return;
            if(dir === 'right') window.Livewire.emit('swipeRight');
            if(dir === 'left') window.Livewire.emit('swipeLeft');
        }

        // Simple touch swipe detection for mobile
        (function(){
            const el = document.getElementById('card');
            if(!el) return;
            let startX = 0;
            el.addEventListener('touchstart', e => startX = e.touches[0].clientX);
            el.addEventListener('touchend', e => {
                let dx = (e.changedTouches[0].clientX - startX);
                if(Math.abs(dx) < 40) return; // tap or small move
                if(dx > 0) window.Livewire.emit('swipeRight'); else window.Livewire.emit('swipeLeft');
            });
        })();
    </script>
</div>
