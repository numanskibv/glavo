<div class="p-4 max-w-xl mx-auto">
    <h2 class="text-xl font-semibold text-white mb-4">Docent Dashboard</h2>

    <form wire:submit.prevent="createCourse" class="mb-4">
        <input type="text" wire:model.defer="courseTitle" placeholder="Nieuwe cursus titel" class="w-full p-3 rounded-lg bg-gray-800 text-white" />
        <button class="mt-2 px-4 py-2 bg-yellow-400 text-black rounded-lg">Maak cursus</button>
    </form>

    <div class="mb-6">
        <label class="block text-sm text-gray-300">Importeer CSV (kolommen: 'дума', 'обяснение')</label>
        <input wire:model="file" type="file" accept="text/csv" class="mt-2" />
        <div class="mt-2">
            <button wire:click.prevent="importCsv" class="px-3 py-2 bg-yellow-400 rounded">Importeer</button>
        </div>
    </div>

    <div>
        <h3 class="text-lg text-gray-200">Je cursussen</h3>
        <ul class="mt-3 space-y-2">
            @foreach($courses as $course)
                <li class="p-3 bg-gray-900 rounded-lg">
                    <div class="flex justify-between items-center">
                        <div>
                            <div class="text-white font-medium">{{ $course->title }}</div>
                            <div class="text-sm text-gray-400">{{ $course->lessons->count() }} lessen</div>
                        </div>
                        <a href="#" class="text-yellow-400">Open</a>
                    </div>
                </li>
            @endforeach
        </ul>
    </div>
</div>
