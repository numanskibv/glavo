<?php

namespace App\Http\Livewire;

use App\Models\Flashcard;
use App\Models\FlashcardAttempt;
use Livewire\Component;

class FlashcardSwipe extends Component
{
    public $drawPile = [];
    public $current;
    public $flipped = false;

    protected $listeners = ['swipeRight' => 'markCorrect', 'swipeLeft' => 'markWrong'];

    public function mount($lessonId = null)
    {
        // Load initial pile: lesson-specific or all
        $query = Flashcard::with('term');
        if ($lessonId) $query->where('lesson_id', $lessonId);
        $this->drawPile = $query->orderBy('mastery', 'asc')->limit(100)->get()->map->id->toArray();
        $this->advance();
    }

    public function advance()
    {
        if (empty($this->drawPile)) {
            $this->current = null;
            return;
        }
        $id = array_shift($this->drawPile);
        $this->current = Flashcard::with('term')->find($id);
        $this->flipped = false;
    }

    public function flip()
    {
        $this->flipped = ! $this->flipped;
    }

    public function markCorrect()
    {
        if (! $this->current) return;
        $this->current->markCorrect();
        FlashcardAttempt::create([
            'flashcard_id' => $this->current->id,
            'user_id' => auth()->id(),
            'correct' => true,
        ]);
        // good cards get reprioritized later - we don't re-add immediately
        $this->advance();
    }

    public function markWrong()
    {
        if (! $this->current) return;
        $this->current->markWrong();
        FlashcardAttempt::create([
            'flashcard_id' => $this->current->id,
            'user_id' => auth()->id(),
            'correct' => false,
        ]);
        // put it back to the front of the pile
        array_unshift($this->drawPile, $this->current->id);
        $this->advance();
    }

    public function getEfficiencyProperty()
    {
        $attempts = FlashcardAttempt::where('user_id', auth()->id())->count();
        $correct = FlashcardAttempt::where('user_id', auth()->id())->where('correct', true)->count();
        if ($attempts === 0) return 0;
        return (int) round(($correct / $attempts) * 100);
    }

    public function render()
    {
        return view('livewire.flashcard-swipe');
    }
}
