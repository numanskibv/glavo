<?php

namespace App\Http\Livewire;

use App\Models\Course;
use App\Models\Lesson;
use App\Models\Term;
use App\Models\Flashcard;
use Livewire\Component;
use Livewire\WithFileUploads;

class TeacherDashboard extends Component
{
    use WithFileUploads;

    public $courseTitle;
    public $file; // CSV upload
    public $courseId;

    protected $rules = [
        'courseTitle' => 'required|string|max:255',
    ];

    public function render()
    {
        $courses = Course::where('teacher_id', auth()->id())->with('lessons')->get();
        return view('livewire.teacher-dashboard', compact('courses'));
    }

    public function createCourse()
    {
        $this->validate();
        Course::create([ 'title' => $this->courseTitle, 'teacher_id' => auth()->id() ]);
        $this->courseTitle = '';
        $this->emit('saved');
    }

    public function importCsv()
    {
        if (! $this->file) return $this->addError('file', 'Upload a CSV first.');

        $path = $this->file->getRealPath();
        $handle = fopen($path, 'r');
        if ($handle === false) return $this->addError('file', 'Could not read file.');

        $header = null;
        $count = 0;
        while (($row = fgetcsv($handle, 0, ',')) !== false) {
            if (! $header) {
                $header = array_map('trim', $row);
                continue;
            }
            $data = array_combine($header, $row);
            // Support columns 'дума' and 'обяснение' (Bulgarian)
            $word = $data['дума'] ?? ($data['word'] ?? null);
            $definition = $data['обяснение'] ?? ($data['definition'] ?? null);
            if (! $word) continue;

            // create term and flashcard
            $lang = \App\Models\Language::firstOrCreate(['code' => 'bg'], ['name' => 'Bulgarian']);
            $term = Term::create([
                'word' => $word,
                'definition' => $definition,
                'language_id' => $lang->id,
            ]);
            Flashcard::create([
                'term_id' => $term->id,
                'teacher_id' => auth()->id(),
            ]);
            $count++;
        }
        fclose($handle);
        $this->file = null;
        $this->emit('imported', $count);
    }
}
